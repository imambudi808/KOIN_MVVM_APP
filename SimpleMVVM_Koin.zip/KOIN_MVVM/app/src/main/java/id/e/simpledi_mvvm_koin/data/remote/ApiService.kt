package id.e.simpledi_mvvm_koin.data.remote

import retrofit2.http.GET
import io.reactivex.Observable

interface ApiService {

    @GET("destination")
    fun getDest(): Observable<DestinationResponseModel>
}