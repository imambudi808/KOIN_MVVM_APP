package id.e.simpledi_mvvm_koin.base

import androidx.appcompat.app.AppCompatActivity

abstract class BaseActivity :AppCompatActivity()