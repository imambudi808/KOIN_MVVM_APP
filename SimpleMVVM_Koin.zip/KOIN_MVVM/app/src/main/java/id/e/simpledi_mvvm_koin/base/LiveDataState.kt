package id.e.simpledi_mvvm_koin.base

import id.e.simpledi_mvvm_koin.presentation.model.Destination

sealed class LiveDataState

data class ShowDest(val dataDes:List<Destination>) : LiveDataState()
data class OnLoading(val show: Boolean) : LiveDataState()
data class OnError(val msg: String) : LiveDataState()