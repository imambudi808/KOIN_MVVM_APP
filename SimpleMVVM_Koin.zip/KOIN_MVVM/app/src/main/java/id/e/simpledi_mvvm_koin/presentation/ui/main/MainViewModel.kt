package id.e.simpledi_mvvm_koin.presentation.ui.main

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.OnLifecycleEvent
import id.e.simpledi_mvvm_koin.base.BaseViewModel
import id.e.simpledi_mvvm_koin.base.OnError
import id.e.simpledi_mvvm_koin.base.OnLoading
import id.e.simpledi_mvvm_koin.base.ShowDest
import id.e.simpledi_mvvm_koin.data.repository.DestinationRepository
import id.e.simpledi_mvvm_koin.presentation.model.Destination
import id.e.simpledi_mvvm_koin.utils.logE
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlin.math.log

class MainViewModel(private val repo:DestinationRepository) : BaseViewModel() {
    private lateinit var desList:MutableList<Destination>

    fun getDes(){
        if (this::desList.isInitialized){
            liveDataState.value = ShowDest(desList)
            return
        }

        desList = mutableListOf()
        disposables.add(
            repo.getDataDestination()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe{
                    liveDataState.value = OnLoading(false)
                }
                .subscribe({
                    this.desList.addAll(it)
                    liveDataState.value = ShowDest(desList)
                },this::onError)
        )
    }

    private fun onError(t: Throwable){
        liveDataState.value = OnError(t.localizedMessage)
        t.printStackTrace()
        logE(t.message)
    }

//    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
//    private fun onDestroy() {
//        dispose()
//    }
}