package id.e.simpledi_mvvm_koin.di

import id.e.simpledi_mvvm_koin.data.repository.DestinationRepository
import org.koin.dsl.module.module

val repositoryModule = module {
    single {
        DestinationRepository(get())
    }
}