package id.e.simpledi_mvvm_koin.di

import id.e.simpledi_mvvm_koin.presentation.ui.main.MainViewModel
import org.koin.dsl.module.module

val viewModelModule = module {
    single {
        MainViewModel(get())
    }
}