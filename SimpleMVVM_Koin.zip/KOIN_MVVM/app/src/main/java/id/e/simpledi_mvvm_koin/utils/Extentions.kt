package id.e.simpledi_mvvm_koin.utils

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.google.gson.Gson

fun Any?.toJson() = Gson().toJsonTree(this)

inline fun <reified T> T.logD(msg: String?) {
    val tag = T::class.java.simpleName
    Log.d(tag, msg)
}

inline fun <reified T> T.logE(msg: String?) {
    val tag = T::class.java.simpleName
    Log.e(tag, msg)
}

fun Context.toast(message: String?) = message?.let {
    Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
}