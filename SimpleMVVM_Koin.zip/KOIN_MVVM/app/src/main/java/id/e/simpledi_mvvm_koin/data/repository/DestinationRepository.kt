package id.e.simpledi_mvvm_koin.data.repository

import id.e.simpledi_mvvm_koin.data.remote.ApiService
import id.e.simpledi_mvvm_koin.presentation.model.Destination
import io.reactivex.Observable


class DestinationRepository(val api:ApiService) {
    fun getDataDestination(): Observable<List<Destination>> {
        return api.getDest()
            .flatMapIterable {
                it.data
            }
            .map {
                Destination(
                    namaDes = it.destName
                )
            }
            .toList()
            .toObservable()
    }
}