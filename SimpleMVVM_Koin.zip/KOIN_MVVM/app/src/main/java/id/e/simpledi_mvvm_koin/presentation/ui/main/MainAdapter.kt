package id.e.simpledi_mvvm_koin.presentation.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import id.e.simpledi_mvvm_koin.R
import id.e.simpledi_mvvm_koin.presentation.model.Destination
import kotlinx.android.synthetic.main.item_list.view.*

class MainAdapter(private val onItemClick:(data:Destination) -> Unit):RecyclerView.Adapter<MainAdapter.MainHolder>() {

    private val destinationList = mutableListOf<Destination>()

    fun addItems(desData:List<Destination>){
        destinationList.addAll(desData)
        notifyItemRangeChanged(itemCount,destinationList.size)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.item_list,parent,false)
        return MainHolder(view)
    }

    override fun getItemCount(): Int =destinationList.size

    override fun onBindViewHolder(holder: MainHolder, position: Int) {
        val dataDst = destinationList[position]
        holder.bind(dataDst)
        holder.itemView.setOnClickListener{
            onItemClick(dataDst)
        }
    }

    inner class MainHolder(itemView:View):RecyclerView.ViewHolder(itemView) {
        fun bind(data: Destination) = with(itemView){
            tvNamaDes.text=data.namaDes
        }
    }
}