package id.e.simpledi_mvvm_koin.data.remote

import com.google.gson.annotations.SerializedName

data class DestinationResponseModel (
    @field:SerializedName("status")
    val status:String?,

    @field:SerializedName("pesan")
    val pesan:String?,

    @field:SerializedName("data")
    val data:List<DestinationModel>
)