package id.e.simpledi_mvvm_koin.presentation.model

data class Destination (
    val namaDes:String?
)