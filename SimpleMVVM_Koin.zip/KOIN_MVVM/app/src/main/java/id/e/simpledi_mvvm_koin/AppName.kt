package id.e.simpledi_mvvm_koin

import android.app.Application
import id.e.simpledi_mvvm_koin.di.networkModule
import id.e.simpledi_mvvm_koin.di.repositoryModule
import id.e.simpledi_mvvm_koin.di.viewModelModule
import org.koin.android.ext.android.startKoin

class AppName : Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin(this, listOf(networkModule, repositoryModule, viewModelModule))
    }
}