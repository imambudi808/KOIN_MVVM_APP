package id.e.simpledi_mvvm_koin.presentation.ui.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import id.e.simpledi_mvvm_koin.R
import id.e.simpledi_mvvm_koin.base.*
import id.e.simpledi_mvvm_koin.presentation.model.Destination
import id.e.simpledi_mvvm_koin.utils.logD
import id.e.simpledi_mvvm_koin.utils.toJson
import id.e.simpledi_mvvm_koin.utils.toast
import kotlinx.android.synthetic.main.activity_main.*
import org.koin.android.viewmodel.ext.android.viewModel


class MainActivity : BaseActivity(), Observer<LiveDataState> {

    private val mainViewModel by viewModel<MainViewModel>()
    private val mainAdapter=MainAdapter{des ->
        toast(des.namaDes)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupView()

        mainViewModel.liveDataState.observe(this,this)
        mainViewModel.getDes()
    }

    override fun onChanged(t: LiveDataState?) {
        when (t) {
            is ShowDest -> showNews(t.dataDes)
            is OnLoading -> showProgress(t.show)
            is OnError -> toast(t.msg)
        }
    }

    private fun setupView(){
        recyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = mainAdapter
        }
    }

    private fun showProgress(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun showNews(news: List<Destination>) {
        logD("showNews : ${news.toJson()}")
        mainAdapter.addItems(news)
    }


}
