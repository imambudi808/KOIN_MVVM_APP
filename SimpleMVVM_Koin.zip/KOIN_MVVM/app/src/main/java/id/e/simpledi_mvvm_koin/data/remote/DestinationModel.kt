package id.e.simpledi_mvvm_koin.data.remote

import com.google.gson.annotations.SerializedName

data class DestinationModel(
    @field:SerializedName("destination_name")
    val destName:String?
)